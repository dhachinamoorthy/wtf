var express=require('express');
var bodyParser=require('body-parser');
var mongoose=require('mongoose');
const app=express();

app.use(express.static('public'));
app.use(bodyParser.urlencoded({
    extended:true
}))

app.set('view engine','ejs');

mongoose.connect('mongodb://localhost:27017/Register',{useNewUrlParser:true,})

//creating schema

var PersonSchema = {
    name : String,
    mobile : Number,
    gender : String,
    address : String
};

const Person = mongoose.model("Person",PersonSchema);



app.post('/login',(req,res)=>{
    var name=req.body.name;
    var mobile=req.body.mobile;
    var gender=req.body.gender;
    var address=req.body.address;
    
    var data=new Person({
        name:name,
        mobile:mobile,
        gender:gender,
        address:address
    });

    data.save();
    console.log("Data inserted successfully");
    res.redirect("/");
  
})


app.post('/update',async(req,res)=>{
 var name=req.body.name;
 var mobile=req.body.mobile;
Person.updateOne({name:name},{mobile:mobile},function(err){
    if(err) console.log(err);
    else console.log("Document updated");
 })
 res.redirect("/");
})

app.post('/delete', (req,res)=>{
    var name=req.body.name;
    var mobile=req.body.mobile;
   

    Person.deleteMany({name :name},function(err){
        if(err) console.log(err);
        else console.log("deleted");
    })

    res.redirect("/");
})

app.post("/display",function(req,res){
    Person.find({},function(err,people){
        res.render("display",{people:people});
    })
})


app.get('/', (req, res)=>{
    res.render('login');
})
app.listen(3000,()=>{
console.log('connected to browser');
});