loginserver.php

<?php
 session_start();

$conn = new mysqli('localhost', 'root', '','details');

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $user = $_POST['user'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password =$_POST['password'];
    
    $sql = "INSERT INTO test VALUES('$id','$user','$phone','$email','$password')";
    $result = mysqli_query($conn, $sql); 
} 
$results = mysqli_query($conn, "SELECT * FROM test");
?>

<table>
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>phone</th>
            <th>Email</th>
            <th>Password</th>
        </tr>
    </thead>
    
    <?php while ($row = mysqli_fetch_array($results)) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['user']; ?></td>
            <td><?php echo $row['phone']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['password']; ?></td>
        </tr>
    <?php } ?>
</table>

<form>  