login.php

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login Form </title>
</head>
<body>
    <div class="container">
        <form action="loginserver.php" method="post" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Login</p>
            <div class="input-group">
                <input type="text" placeholder="ID" name="id"  required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="Username" name="user"  required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="Phone" name="phone"  required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="Email" name="email"  required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password"  required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Login</button>
            </div>
        </form>
    </div>
</body>
</html>
